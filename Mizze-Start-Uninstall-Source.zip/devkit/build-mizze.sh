#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
# main.swift permits top-level assertions alongside the reusable state file.
cp Tests/MizzeAppStateTests.swift build/main.swift
swiftc TrollFools/MizzeAppState.swift build/main.swift -o build/app-state-tests
./build/app-state-tests | tee build/app-state-tests.log
sips -s format png -z 1024 1024 TrollFools/MizzeLogo.jpg --out TrollFools/Assets.xcassets/AppIcon.appiconset/AppIcon.png >/dev/null
xcodebuild -project TrollFools.xcodeproj -scheme TrollFools -configuration Release \
  -sdk iphoneos -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build 2>&1 | tee build/xcodebuild.log
APP="build/DerivedData/Build/Products/Release-iphoneos/TrollFools.app"
test -f "$APP/MizzePayload.zip"
test -f "$APP/TrollFools"
chmod +x "$APP/TrollFools"
for name in chown cp cp-15 ct_bypass insert_dylib mkdir mv mv-15 rm; do
  test -f "$APP/$name"; chmod +x "$APP/$name"
done
python3 devkit/verify-app.py "$APP"
ldid -STrollFools/TrollFools.entitlements "$APP/TrollFools"
mkdir -p build/Package/Payload
ditto "$APP" build/Package/Payload/Mizze.app
(cd build/Package && zip -qry ../Mizze-Start-Uninstall.tipa Payload)
cp build/Mizze-Start-Uninstall.tipa build/Mizze-Start-Uninstall.ipa
shasum -a 256 build/Mizze-Start-Uninstall.tipa > build/Mizze-Start-Uninstall.sha256
