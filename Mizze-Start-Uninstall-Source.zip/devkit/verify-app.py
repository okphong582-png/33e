from pathlib import Path
import hashlib,json,plistlib,sys,zipfile
app=Path(sys.argv[1]); expected={'bundleID': 'hoangha.mizze.com', 'target': 'com.dts.freefireth', 'dylibSha256': '24700ff2f842588307fb9152a161df3807e25c8c457b15245431ebf91dcc5080', 'payloadSha256': '31e1b777e87938d132218e3f3e04c67e978843ca08176130612c3529e88c0ae6', 'payloadUUID': '4c4c440155553144a1694bcc41a1514b', 'uninstallScope': 'Only Mizze.dylib'}
info=plistlib.loads((app/'Info.plist').read_bytes())
assert info['CFBundleIdentifier']==expected['bundleID']
assert info['CFBundleDisplayName']=='Mizze'
payload=(app/'MizzePayload.zip').read_bytes()
assert hashlib.sha256(payload).hexdigest()==expected['payloadSha256']
with zipfile.ZipFile(app/'MizzePayload.zip') as z:
 assert z.namelist()==['Mizze.dylib']
 assert hashlib.sha256(z.read('Mizze.dylib')).hexdigest()==expected['dylibSha256']
report={**expected,'builtBundleID':info['CFBundleIdentifier'],'physicalIphoneTested':False,'payloadVerified':True}
Path('build/app-verification.json').write_text(json.dumps(report,indent=2))
print('Verified bundle ID, embedded dylib, payload hash and target')
