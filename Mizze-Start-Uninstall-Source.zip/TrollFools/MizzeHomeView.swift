import CryptoKit
import SwiftUI
import UIKit

final class MizzeBackend: MizzeAppBackend {
    static let targetID = "com.dts.freefireth"
    static let payloadHash = "31e1b777e87938d132218e3f3e04c67e978843ca08176130612c3529e88c0ae6"
    static let payloadUUID = "4c4c440155553144a1694bcc41a1514b"
    private func injector() throws -> InjectorV3 {
        guard let proxy = LSApplicationProxy(forIdentifier: Self.targetID),
              proxy.applicationIdentifier() == Self.targetID,
              let url = proxy.bundleURL(), FileManager.default.fileExists(atPath: url.path)
        else { throw MizzeAppError.missingGame }
        let engine = try InjectorV3(url)
        guard engine.appID == Self.targetID else { throw MizzeAppError.wrongGame }
        if engine.teamID.isEmpty { engine.teamID = proxy.teamID() ?? "0000000000" }
        engine.useWeakReference = true
        return engine
    }
    private func ours(_ urls: [URL]) -> [URL] {
        urls.filter { $0.lastPathComponent.caseInsensitiveCompare("Mizze.dylib") == .orderedSame }
    }
    func inspect() throws -> MizzeInstallState {
        let engine = try injector()
        let file = engine.bundleURL.appendingPathComponent("Frameworks/Mizze.dylib").standardizedFileURL
        let exists = FileManager.default.fileExists(atPath: file.path)
        let base = engine.bundleURL.standardizedFileURL.path + "/"
        let linked = try exists && MizzeLiveGraph.reaches(engine.executableURL.standardizedFileURL.path, target: file.path) { path in
            try engine.loadedDylibsOfMachO(URL(fileURLWithPath: path)).compactMap { name in
                guard let url = engine.mizzeResolveLiveLoadCommand(name)?.standardizedFileURL,
                      url.path.hasPrefix(base), FileManager.default.fileExists(atPath: url.path)
                else { return nil }
                return url.path
            }
        }
        let managed = exists || !ours(engine.persistedAssetURLs(bid: Self.targetID)).isEmpty
        let current = exists && (try? Data(contentsOf: file)).flatMap(MizzeMachOIdentity.uuid) == Self.payloadUUID
        return MizzeInstallState(linked: linked, currentPayload: current, managedFiles: managed)
    }
    func start() throws {
        // Validate the complete bundled payload before changing the target app.
        guard let payload = Bundle.main.url(forResource: "MizzePayload", withExtension: "zip")
        else { throw MizzeAppError.missingPayload }
        let bytes = try Data(contentsOf: payload)
        let hash = SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
        guard hash == Self.payloadHash else { throw MizzeAppError.payloadMismatch }
        let previous = try inspect()
        if previous.managedFiles { try uninstall() }
        try injector().inject([payload], shouldPersist: false)
    }
    func uninstall() throws {
        let engine = try injector()
        let injected = ours(engine.injectedAssetURLsInBundle(engine.bundleURL))
        if !injected.isEmpty { try engine.eject(injected, shouldDesist: true) }
        let persisted = ours(engine.persistedAssetURLs(bid: Self.targetID))
        if !persisted.isEmpty { engine.desist(persisted) }
    }
}

final class MizzeScreenModel: ObservableObject {
    @Published var busy = false
    @Published var available = false
    @Published var installed = false
    @Published var message = "Đang kiểm tra Free Fire TH…"
    @Published var failure: String?
    private let backend = MizzeBackend()
    private let worker = DispatchQueue(label: "hoangha.mizze.commands", qos: .userInitiated)
    func refresh() { perform(nil) }
    func run(_ command: MizzeCommand) { perform(command) }
    private func perform(_ command: MizzeCommand?) {
        guard !busy else { return }
        busy = true
        if let command { message = command == .start ? "Đang gắn Mizze…" : "Đang gỡ Mizze…" }
        worker.async { [self] in
            do {
                let state = try command.map { try MizzeCommandRunner(backend: backend).run($0) } ?? backend.inspect()
                DispatchQueue.main.async { [self] in
                    installed = state.linked && state.currentPayload
                    available = true; busy = false
                    message = installed ? "Đã gắn Mizze · Mở lại game để sử dụng" : "Sẵn sàng"
                    if command == .uninstall { message = "Đã gỡ Mizze" }
                }
            } catch {
                let observed = try? backend.inspect()
                let text = error.localizedDescription
                DispatchQueue.main.async { [self] in
                    installed = observed?.linked == true
                    available = observed != nil; busy = false; message = text
                    if command != nil { failure = text }
                }
            }
        }
    }
}

struct MizzeHomeView: View {
    @StateObject private var model = MizzeScreenModel()
    @Environment(\.scenePhase) private var scenePhase
    private let ink = Color(red: 0.12, green: 0.20, blue: 0.30)
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color(red: 0.83, green: 0.91, blue: 0.98), .white, Color(red: 0.89, green: 0.88, blue: 0.97)]), startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            VStack(spacing: 0) {
                Spacer()
                Image("MizzeLogo").resizable().scaledToFit().frame(width: 88, height: 88).clipShape(Circle())
                    .overlay(Circle().stroke(Color.white.opacity(0.8), lineWidth: 1)).shadow(color: ink.opacity(0.12), radius: 18, y: 8)
                Text("MIZZE").font(.system(size: 30, weight: .bold, design: .rounded)).tracking(5).padding(.top, 20)
                Text("FREE FIRE TH").font(.system(size: 10, weight: .semibold)).tracking(3).opacity(0.6).padding(.top, 8)
                VStack(spacing: 12) {
                    Text(model.message).font(.system(size: 13)).multilineTextAlignment(.center).frame(minHeight: 42)
                    action("Start", icon: "play.fill", command: .start, primary: true)
                    action("Uninstall", icon: "minus.circle", command: .uninstall, primary: false)
                }.padding(22).background(Color.white.opacity(0.40)).cornerRadius(26)
                    .overlay(RoundedRectangle(cornerRadius: 26).stroke(Color.white.opacity(0.8), lineWidth: 1))
                    .padding(.top, 28).padding(.horizontal, 28).frame(maxWidth: 430)
                Spacer()
            }.foregroundColor(ink)
            if model.busy { ProgressView().progressViewStyle(CircularProgressViewStyle(tint: ink)).offset(y: 230) }
        }
        .onAppear { model.refresh() }
        .onChange(of: scenePhase) { if $0 == .active { model.refresh() } }
        .alert(isPresented: Binding(get: { model.failure != nil }, set: { if !$0 { model.failure = nil } })) {
            Alert(title: Text("Mizze"), message: Text(model.failure ?? ""), dismissButton: .default(Text("OK")))
        }
    }
    private func action(_ title: String, icon: String, command: MizzeCommand, primary: Bool) -> some View {
        Button { model.run(command) } label: {
            HStack(spacing: 10) { Image(systemName: icon); Text(title).fontWeight(.semibold) }
                .font(.system(size: 16)).frame(maxWidth: .infinity).frame(height: 52)
                .foregroundColor(primary ? .white : ink)
                .background(primary ? ink : Color.white.opacity(0.55)).cornerRadius(16)
        }.disabled(model.busy || !model.available).opacity(model.busy || !model.available ? 0.55 : 1)
    }
}
