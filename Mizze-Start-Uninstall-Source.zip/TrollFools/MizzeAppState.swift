import Foundation

struct MizzeInstallState {
    let linked: Bool
    let currentPayload: Bool
    let managedFiles: Bool
}
enum MizzeCommand: Equatable { case start, uninstall }
enum MizzeAppError: LocalizedError {
    case missingGame, wrongGame, missingPayload, payloadMismatch, startNotVerified, uninstallNotVerified
    var errorDescription: String? {
        switch self {
        case .missingGame: return "Chưa tìm thấy Free Fire TH trên máy."
        case .wrongGame: return "Ứng dụng đích không đúng Free Fire TH."
        case .missingPayload: return "Thiếu dylib Mizze trong gói ứng dụng."
        case .payloadMismatch: return "Dylib đóng gói không khớp bản build."
        case .startNotVerified: return "Chưa xác nhận được Mizze đã được gắn vào game."
        case .uninstallNotVerified: return "Mizze chưa được gỡ hoàn toàn."
        }
    }
}
protocol MizzeAppBackend {
    func inspect() throws -> MizzeInstallState
    func start() throws
    func uninstall() throws
}
struct MizzeCommandRunner {
    let backend: MizzeAppBackend
    func run(_ command: MizzeCommand) throws -> MizzeInstallState {
        let initial = try backend.inspect()
        switch command {
        case .start:
            if initial.linked && initial.currentPayload { return initial }
            try backend.start()
            let final = try backend.inspect()
            guard final.linked && final.currentPayload else { throw MizzeAppError.startNotVerified }
            return final
        case .uninstall:
            if !initial.linked && !initial.managedFiles { return initial }
            try backend.uninstall()
            let final = try backend.inspect()
            guard !final.linked && !final.managedFiles else { throw MizzeAppError.uninstallNotVerified }
            return final
        }
    }
}
enum MizzeLiveGraph {
    // Inspect current files, including injected edges. TrollFools' enumeration
    // helper intentionally follows pre-injection backups and cannot verify Start.
    static func reaches(_ root: String, target: String, children: (String) throws -> [String]) rethrows -> Bool {
        var pending = [root], visited = Set<String>()
        while let next = pending.popLast() {
            if next == target { return true }
            if visited.contains(next) { continue }
            visited.insert(next)
            if visited.count > 2048 { return false }
            pending.append(contentsOf: try children(next))
        }
        return false
    }
}
enum MizzeMachOIdentity {
    static func uuid(_ data: Data) -> String? {
        let b = [UInt8](data)
        func word(_ p: Int) -> UInt32 {
            UInt32(b[p]) | UInt32(b[p+1]) << 8 | UInt32(b[p+2]) << 16 | UInt32(b[p+3]) << 24
        }
        guard b.count >= 32, word(0) == 0xfeedfacf else { return nil }
        let count = Int(word(16)), length = Int(word(20))
        guard count < 4096, length <= b.count - 32 else { return nil }
        var p = 32
        for _ in 0..<count {
            guard p + 8 <= 32 + length else { return nil }
            let command = word(p), size = Int(word(p+4))
            guard size >= 8, size <= 32 + length - p else { return nil }
            if command == 0x1b {
                guard size >= 24 else { return nil }
                return b[(p+8)..<(p+24)].map { String(format: "%02x", $0) }.joined()
            }
            p += size
        }
        return nil
    }
}
