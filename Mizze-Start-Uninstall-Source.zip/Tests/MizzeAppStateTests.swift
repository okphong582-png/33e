import Foundation

final class FakeBackend: MizzeAppBackend {
    var state = MizzeInstallState(linked: false, currentPayload: false, managedFiles: false)
    var starts = 0, removals = 0
    var failStart = false, failRemoval = false
    var unrelatedPlugin = true
    func inspect() throws -> MizzeInstallState { state }
    func start() throws {
        starts += 1
        if !failStart { state = MizzeInstallState(linked: true, currentPayload: true, managedFiles: true) }
    }
    func uninstall() throws {
        removals += 1
        if !failRemoval { state = MizzeInstallState(linked: false, currentPayload: false, managedFiles: false) }
    }
}
let backend = FakeBackend()
let runner = MizzeCommandRunner(backend: backend)
let started = try runner.run(.start)
assert(started.currentPayload)
assert(backend.starts == 1)
let repeated = try runner.run(.start)
assert(repeated.linked)
assert(backend.starts == 1, "Start must not toggle a current installation off")
let removed = try runner.run(.uninstall)
assert(!removed.linked)
assert(backend.unrelatedPlugin && backend.removals == 1)
let removedAgain = try runner.run(.uninstall)
assert(!removedAgain.linked)
assert(backend.removals == 1)
backend.state = MizzeInstallState(linked: true, currentPayload: false, managedFiles: true)
let updated = try runner.run(.start)
assert(updated.currentPayload)
assert(backend.starts == 2, "Old payload must be updated")
backend.failRemoval = true
do { _ = try runner.run(.uninstall); assertionFailure("False uninstall success") }
catch MizzeAppError.uninstallNotVerified { }
catch { fatalError("Unexpected error: \(error)") }
backend.failRemoval = false
_ = try runner.run(.uninstall)
backend.failStart = true
do { _ = try runner.run(.start); assertionFailure("False Start success") }
catch MizzeAppError.startNotVerified { }
catch { fatalError("Unexpected error: \(error)") }
// Live links differ from backups and may include cycles/shared dependencies.
let graph = ["main": ["Unity"], "Unity": ["DataDome"], "DataDome": ["Mizze", "Unity"], "Mizze": []]
assert(MizzeLiveGraph.reaches("main", target: "Mizze") { graph[$0] ?? [] })
assert(!MizzeLiveGraph.reaches("main", target: "Other") { graph[$0] ?? [] })
assert(!MizzeLiveGraph.reaches("main", target: "Mizze") { $0 == "main" ? ["Unity-original"] : [] })
assert(MizzeMachOIdentity.uuid(Data()) == nil)
print("PASS: Start, repeated Start, update, selective Uninstall, failed verification, current-file graph, cycles, malformed Mach-O")
